﻿namespace FoodDash.Web.Common.Enums
{
    public enum ProductType
    {
        Burger = 1,
        Pizza = 2,
        Pasta = 3,
        Salad = 4,
        Menu = 5,
        Drink = 6
    }
}
