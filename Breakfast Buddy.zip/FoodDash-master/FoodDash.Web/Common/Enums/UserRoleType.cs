﻿namespace FoodDash.Web.Common.Enums
{
    public enum UserRoleType
    {
        Customer = 1,
        Admin = 2
    }
}
