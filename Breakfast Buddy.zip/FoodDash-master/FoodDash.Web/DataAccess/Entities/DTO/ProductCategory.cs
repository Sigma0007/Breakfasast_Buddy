﻿namespace FoodDash.Web.DataAccess.DTO
{
    public class ProductCategory
    {
        public int ProductCategoryId { get; set; }

        public string ProductCategoryName { get; set; }
    }
}
